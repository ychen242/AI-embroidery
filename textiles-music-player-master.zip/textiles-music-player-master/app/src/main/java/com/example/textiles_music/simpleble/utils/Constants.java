package com.example.textiles_music.simpleble.utils;

public class Constants {


    //------ BluetoothLE Services and Characteristics

    public static final String SERVICE_COLLAR_INFO              = "cfc47cd2-4dc5-11ee-be56-0242ac120002";
    public static final String CHARACTERISTIC_NOTIFICATION = "cfc47cd2-4dc5-11ee-be56-0242ac120003";
}
